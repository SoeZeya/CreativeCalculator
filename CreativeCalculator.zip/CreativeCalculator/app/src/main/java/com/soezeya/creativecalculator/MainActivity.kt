package com.soezeya.creativecalculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var resultDisplay: TextView //for the selected combination and result//
    private val selectedConcepts = mutableSetOf<String>()

    // All possible combinations with creative results
    // using mapOf to store the combinations and their results
    private val conceptResults = mapOf(
        // Single concepts
        setOf("Love") to "Heart Opener (Capacity for deep connection)",
        setOf("Happiness") to "Pure Joy (State of contentment)",
        setOf("Creativity") to "Endless Possibilities (Flow of new ideas)",
        setOf("Friendship") to "Loyal Companion (Bond that lasts)",
        setOf("Knowledge") to "Wisdom Seeker (Understanding of truth)",
        setOf("Balance") to "Harmony Keeper (Perfect equilibrium)",
        setOf("Patience") to "Time Master (Art of waiting gracefully)",
        setOf("Courage") to "Fear Conqueror (Strength in adversity)",

        // Two-concept combinations
        setOf("Love", "Happiness") to "Blissful Union (Perfect emotional harmony)",
        setOf("Love", "Creativity") to "Passionate Expression (Art born from affection)",
        setOf("Love", "Friendship") to "Soul Connection (Deep platonic bond)",
        setOf("Love", "Knowledge") to "Enlightened Heart (Love with understanding)",
        setOf("Love", "Balance") to "Stable Affection (Healthy loving relationship)",
        setOf("Love", "Patience") to "Everlasting Devotion (Love that endures)",
        setOf("Love", "Courage") to "Brave Heart (Willingness to fight for love)",
        setOf("Happiness", "Creativity") to "Joyful Innovation (Happy ideas flowing)",
        setOf("Happiness", "Friendship") to "Shared Laughter (Joy multiplied by company)",
        setOf("Happiness", "Knowledge") to "Enlightened Joy (Happiness with purpose)",
        setOf("Happiness", "Balance") to "Contentment (Perfect life equilibrium)",
        setOf("Happiness", "Patience") to "Quiet Satisfaction (Joy in waiting)",
        setOf("Happiness", "Courage") to "Fearless Joy (Happiness despite challenges)",
        setOf("Creativity", "Friendship") to "Collaborative Genius (Creating together)",
        setOf("Creativity", "Knowledge") to "Innovation (New solutions from understanding)",
        setOf("Creativity", "Balance") to "Inspired Harmony (Creative flow in balance)",
        setOf("Creativity", "Patience") to "Masterpiece (Great art takes time)",
        setOf("Creativity", "Courage") to "Radical Innovation (Bold new creations)",
        setOf("Friendship", "Knowledge") to "Wise Companionship (Friends who enlighten)",
        setOf("Friendship", "Balance") to "Healthy Relationship (Equal give and take)",
        setOf("Friendship", "Patience") to "Enduring Bond (Friendship that lasts)",
        setOf("Friendship", "Courage") to "Battle Brothers (Friends through thick and thin)",
        setOf("Knowledge", "Balance") to "Practical Wisdom (Knowledge applied rightly)",
        setOf("Knowledge", "Patience") to "Deep Understanding (Mastery through time)",
        setOf("Knowledge", "Courage") to "Truth Seeker (Brave pursuit of knowledge)",
        setOf("Balance", "Patience") to "Zen State (Complete inner peace)",
        setOf("Balance", "Courage") to "Steady Bravery (Courage with measure)",
        setOf("Patience", "Courage") to "Persistent Strength (Enduring bravery)",

        // Three-concept combinations
        setOf("Love", "Happiness", "Creativity") to "Creative Euphoria (Art born from joyful love)",
        setOf("Love", "Friendship", "Balance") to "Perfect Triad (Ideal relationship balance)",
        setOf("Knowledge", "Patience", "Courage") to "Sage Warrior (Wise and brave persistence)",
        setOf("Creativity", "Knowledge", "Balance") to "Renaissance Mind (Brilliant equilibrium)",

        // Four+ concepts
        setOf("Love", "Happiness", "Creativity", "Friendship") to "Utopian Circle (Perfect creative community)",
        setOf("Knowledge", "Balance", "Patience", "Courage") to "Enlightened Master (Complete personal development)",
        setOf("Love", "Happiness", "Balance", "Patience") to "Nirvana (Perfect life harmony)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultDisplay = findViewById(R.id.resultDisplay)

        // Set up all buttons
        // Using forEach to iterate over the list of button IDs
        listOf(
            R.id.btnLove, R.id.btnHappiness, R.id.btnCreativity,
            R.id.btnFriendship, R.id.btnKnowledge, R.id.btnBalance,
            R.id.btnPatience, R.id.btnCourage, R.id.btnClear
        ).forEach { buttonId ->
            findViewById<Button>(buttonId).setOnClickListener { onButtonClick(it) }
        }

        findViewById<Button>(R.id.infoButton).setOnClickListener { showInfoModal() }
    }
//clear the results
    private fun onButtonClick(view: View) {
        when (view.id) {
            R.id.btnClear -> {
                resetAllButtons()
                selectedConcepts.clear()
                resultDisplay.text = getString(R.string.default_display)
            }
            else -> {
                val button = view as Button
                val concept = button.text.toString()

                // Toggle selection
                if (selectedConcepts.contains(concept)) {
                    selectedConcepts.remove(concept)
                    button.setBackgroundColor(getColor(R.color.purple_200))
                } else {
                    selectedConcepts.add(concept)
                    button.setBackgroundColor(getColor(R.color.purple_500))
                }

                updateResultDisplay()
            }
        }
    }

    private fun updateResultDisplay() {
        if (selectedConcepts.isEmpty()) {
            resultDisplay.text = getString(R.string.default_display)
            return
        }

        val combination = selectedConcepts.joinToString(" + ") //creating a string that represents the combinations of all concept
        val result = conceptResults[selectedConcepts] ?: generateDynamicResult() //retrieve the predefined result

        //updating the textview with combination
        resultDisplay.text = """
            Combination: $combination
            
            Result: $result
            
            (${selectedConcepts.size} concepts combined)
        """.trimIndent()
    }

    private fun generateDynamicResult(): String {
        return when (selectedConcepts.size) {
            1 -> "Pure ${selectedConcepts.first()} (Focus on this quality)"
            2 -> "Interesting potential between these concepts"
            3 -> "Powerful triad emerging"
            4 -> "Complex synergy unfolding"
            else -> "Extraordinary combination of ${selectedConcepts.size} qualities"
        }
    }

    private fun resetAllButtons() {
        listOf(
            R.id.btnLove, R.id.btnHappiness, R.id.btnCreativity,
            R.id.btnFriendship, R.id.btnKnowledge, R.id.btnBalance,
            R.id.btnPatience, R.id.btnCourage
        ).forEach { buttonId ->
            findViewById<Button>(buttonId).setBackgroundColor(getColor(R.color.purple_200))
        }
    }

    private fun showInfoModal() {
        MaterialAlertDialogBuilder(this)
            .setTitle("About This Creative Calculator")
            .setMessage("Combine concepts to discover interesting synergies:\n\n" +
                    "• Tap concepts to select/deselect\n" +
                    "• See automatic results for combinations\n" +
                    "• Clear to start fresh\n\n" +
                    "This tool helps explore abstract connections between ideas.")
            .setPositiveButton("Got it!") { dialog, _ -> dialog.dismiss() }
            .setIcon(R.drawable.ic_info)
            .show()
    }
}